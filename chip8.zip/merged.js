/* CHIP-28 — interface et boucle principale */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var hex = Chip28.hex;

  var cpu = new Chip28();
  var screen = new Chip28Screen($('screen'));
  var beeper = new Chip28Beeper();

  var state = { paused: false, ips: 700, romName: '', cycleFrac: 0 };

  // ---------- Réglages sauvegardés ----------
  var STORE = 'chip28.settings';
  function loadSettings() {
    try { return JSON.parse(localStorage.getItem(STORE)) || {}; } catch (e) { return {}; }
  }
  function saveSettings() {
    try {
      localStorage.setItem(STORE, JSON.stringify({
        ips: state.ips,
        quirks: $('quirks').value,
        theme: $('theme').value,
        ghost: $('ghost').checked,
        sound: $('sound').checked
      }));
    } catch (e) { /* stockage indisponible : on ignore */ }
  }

  // ---------- Pavé hexadécimal ----------
  // Disposition d'origine, posée sur les touches physiques (les libellés suivent l'AZERTY).
  var PAD = [
    [0x1, '&'], [0x2, 'é'], [0x3, '"'], [0xC, "'"],
    [0x4, 'A'], [0x5, 'Z'], [0x6, 'E'], [0xD, 'R'],
    [0x7, 'Q'], [0x8, 'S'], [0x9, 'D'], [0xE, 'F'],
    [0xA, 'W'], [0x0, 'X'], [0xB, 'C'], [0xF, 'V']
  ];
  var KEYMAP = {
    Digit1: 0x1, Digit2: 0x2, Digit3: 0x3, Digit4: 0xC,
    KeyQ: 0x4, KeyW: 0x5, KeyE: 0x6, KeyR: 0xD,
    KeyA: 0x7, KeyS: 0x8, KeyD: 0x9, KeyF: 0xE,
    KeyZ: 0xA, KeyX: 0x0, KeyC: 0xB, KeyV: 0xF
  };
  var padEls = {};

  function setKey(k, down) {
    cpu.keys[k] = down ? 1 : 0;
    if (padEls[k]) padEls[k].classList.toggle('down', !!down);
  }

  PAD.forEach(function (p) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'pad';
    b.textContent = p[0].toString(16).toUpperCase();
    var s = document.createElement('small');
    s.textContent = p[1];
    b.appendChild(s);
    b.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      beeper.unlock();
      setKey(p[0], true);
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) {
      b.addEventListener(ev, function () { setKey(p[0], false); });
    });
    $('keypad').appendChild(b);
    padEls[p[0]] = b;
  });

  document.addEventListener('keydown', function (e) {
    var k = KEYMAP[e.code];
    if (k === undefined || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.target && (e.target.tagName === 'SELECT' || e.target.type === 'range')) e.target.blur();
    e.preventDefault();
    beeper.unlock();
    setKey(k, true);
  });
  document.addEventListener('keyup', function (e) {
    var k = KEYMAP[e.code];
    if (k !== undefined) setKey(k, false);
  });
  window.addEventListener('blur', function () {
    for (var k = 0; k < 16; k++) setKey(k, false);
  });

  // ---------- ROMs ----------
  var ROMS = window.CHIP28_ROMS;
  ROMS.forEach(function (r, i) {
    var o = document.createElement('option');
    o.value = String(i);
    o.textContent = r.name;
    o.title = r.desc;
    $('romSelect').appendChild(o);
  });

  function showMessage(text) {
    var ov = $('overlay');
    if (text) { ov.textContent = text; ov.hidden = false; }
    else ov.hidden = true;
  }

  function startRom(bytes, name) {
    try {
      cpu.loadRom(bytes);
    } catch (err) {
      showMessage(err.message);
      return;
    }
    screen.level.fill(0);
    state.romName = name;
    state.paused = false;
    state.cycleFrac = 0;
    showMessage('');
    refreshUI();
  }

  $('romSelect').addEventListener('change', function () {
    var r = ROMS[+this.value];
    startRom(r.bytes, r.name);
    this.blur();
  });

  function readFile(file) {
    if (!file) return;
    var fr = new FileReader();
    fr.onload = function () { startRom(new Uint8Array(fr.result), file.name); };
    fr.onerror = function () { showMessage('Impossible de lire « ' + file.name + ' ».'); };
    fr.readAsArrayBuffer(file);
  }
  $('romFile').addEventListener('change', function () {
    readFile(this.files[0]);
    this.value = '';
  });

  var drop = $('drop');
  ['dragenter', 'dragover'].forEach(function (ev) {
    drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); });
  });
  ['dragleave', 'drop'].forEach(function (ev) {
    drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); });
  });
  drop.addEventListener('drop', function (e) {
    beeper.unlock();
    readFile(e.dataTransfer.files[0]);
  });

  // ---------- Contrôles ----------
  $('btnPause').addEventListener('click', function () {
    state.paused = !state.paused;
    refreshUI();
  });
  $('btnStep').addEventListener('click', function () {
    if (state.paused) { cpu.step(); updateDebug(); }
  });
  $('btnReset').addEventListener('click', function () {
    cpu.reset();
    screen.level.fill(0);
    state.paused = false;
    state.cycleFrac = 0;
    showMessage('');
    refreshUI();
  });

  $('ips').addEventListener('input', function () {
    state.ips = +this.value;
    $('ipsOut').textContent = this.value;
    saveSettings();
  });
  $('quirks').addEventListener('change', function () {
    cpu.setQuirks(Chip28.PRESETS[this.value]);
    saveSettings();
    this.blur();
  });
  $('theme').addEventListener('change', function () {
    screen.setTheme(this.value);
    saveSettings();
    this.blur();
  });
  $('ghost').addEventListener('change', function () { screen.ghost = this.checked; saveSettings(); });
  $('sound').addEventListener('change', function () {
    beeper.enabled = this.checked;
    beeper.unlock();
    saveSettings();
  });

  // ---------- Débogueur ----------
  var regEls = [];
  for (var i = 0; i < 16; i++) {
    var d = document.createElement('div');
    d.innerHTML = '<b>V' + i.toString(16).toUpperCase() + '</b><span>00</span>';
    $('regs').appendChild(d);
    regEls.push(d.lastChild);
  }
  var miscEls = {};
  ['PC', 'I', 'SP', 'DT', 'ST', 'OP'].forEach(function (k) {
    var d = document.createElement('div');
    d.innerHTML = '<dt>' + k + '</dt><dd>-</dd>';
    $('misc').appendChild(d);
    miscEls[k] = d.lastChild;
  });
  var traceEls = [];
  for (var t = 0; t < 8; t++) {
    var li = document.createElement('li');
    $('trace').appendChild(li);
    traceEls.push(li);
  }

  function updateDebug() {
    for (var i = 0; i < 16; i++) regEls[i].textContent = hex(cpu.V[i], 2);
    miscEls.PC.textContent = hex(cpu.pc);
    miscEls.I.textContent = hex(cpu.I & 0xFFF);
    miscEls.SP.textContent = String(cpu.sp);
    miscEls.DT.textContent = hex(cpu.dt, 2);
    miscEls.ST.textContent = hex(cpu.st, 2);
    var last = cpu.trace[(cpu.traceIdx + 15) & 15];
    miscEls.OP.textContent = hex(last & 0xFFFF, 4);
    for (var j = 0; j < 8; j++) {
      var e = cpu.trace[(cpu.traceIdx + 15 - j) & 15];
      var op = e & 0xFFFF, pc = (e >> 16) & 0xFFF;
      traceEls[j].innerHTML = '<span class="a">' + hex(pc) + '</span> ' + Chip28.disasm(op);
    }
  }

  function refreshUI() {
    var led = $('led');
    var status = $('status');
    $('btnPause').textContent = state.paused ? 'Reprendre' : 'Pause';
    $('btnStep').disabled = !state.paused;
    led.className = 'led';
    if (!cpu.rom) {
      status.textContent = 'Aucune ROM chargée';
    } else if (cpu.halted) {
      led.classList.add('err');
      status.textContent = 'Arrêt : ' + cpu.error;
    } else if (state.paused) {
      status.textContent = state.romName + ' — en pause';
    } else {
      led.classList.add('run');
      status.textContent = state.romName + ' — en marche';
    }
  }

  // ---------- Boucle principale ----------
  var last = performance.now(), acc = 0, dbgTimer = 0, wasHalted = false;
  var TICK = 1000 / 60;

  function frame(now) {
    requestAnimationFrame(frame);
    var dt = Math.min(now - last, 100);
    last = now;

    if (cpu.rom && !state.paused && !cpu.halted) {
      acc += dt;
      var n = 0;
      while (acc >= TICK && n < 6) {
        state.cycleFrac += state.ips / 60;
        var c = Math.floor(state.cycleFrac);
        state.cycleFrac -= c;
        cpu.run(c);
        cpu.tickTimers();
        acc -= TICK;
        n++;
      }
      if (n === 6) acc = 0;
    }
    beeper.set(cpu.st > 0 && !state.paused && !cpu.halted);

    if (cpu.halted !== wasHalted) { wasHalted = cpu.halted; refreshUI(); }

    screen.render(cpu.display);

    dbgTimer += dt;
    if (dbgTimer > 100) { dbgTimer = 0; updateDebug(); }
  }

  // ---------- Démarrage ----------
  var s = loadSettings();
  if (s.ips) { state.ips = s.ips; $('ips').value = s.ips; $('ipsOut').textContent = s.ips; }
  if (s.quirks && Chip28.PRESETS[s.quirks]) { $('quirks').value = s.quirks; cpu.setQuirks(Chip28.PRESETS[s.quirks]); }
  if (s.theme) { $('theme').value = s.theme; screen.setTheme(s.theme); }
  if (typeof s.ghost === 'boolean') { $('ghost').checked = s.ghost; screen.ghost = s.ghost; }
  if (typeof s.sound === 'boolean') { $('sound').checked = s.sound; beeper.enabled = s.sound; }

  startRom(ROMS[0].bytes, ROMS[0].name);
  requestAnimationFrame(frame);
})();


/* CHIP-28 — cœur de l'émulateur
 * Processeur 8 bits : 4 Ko de mémoire, 16 registres V0–VF, registre I (adresses),
 * pile de 16 niveaux, 2 timers à 60 Hz, écran monochrome 64×32, clavier hexadécimal à 16 touches.
 * Le jeu d'instructions est compatible CHIP-8 : les ROMs .ch8 existantes fonctionnent.
 */
(function (root) {
  'use strict';

  var W = 64, H = 32;
  var START = 0x200;

  var FONT = [
    0xF0,0x90,0x90,0x90,0xF0, 0x20,0x60,0x20,0x20,0x70, 0xF0,0x10,0xF0,0x80,0xF0, 0xF0,0x10,0xF0,0x10,0xF0,
    0x90,0x90,0xF0,0x10,0x10, 0xF0,0x80,0xF0,0x10,0xF0, 0xF0,0x80,0xF0,0x90,0xF0, 0xF0,0x10,0x20,0x40,0x40,
    0xF0,0x90,0xF0,0x90,0xF0, 0xF0,0x90,0xF0,0x10,0xF0, 0xF0,0x90,0xF0,0x90,0x90, 0xE0,0x90,0xE0,0x90,0xE0,
    0xF0,0x80,0x80,0x80,0xF0, 0xE0,0x90,0x90,0x90,0xE0, 0xF0,0x80,0xF0,0x80,0xF0, 0xF0,0x80,0xF0,0x80,0x80
  ];

  // Variantes de comportement (les ROMs anciennes et récentes ne s'attendent pas aux mêmes choses)
  var PRESETS = {
    moderne: { shiftUsesVY: false, memIncrementI: false, vfReset: false, wrap: false },
    cosmac:  { shiftUsesVY: true,  memIncrementI: true,  vfReset: true,  wrap: false }
  };

  function hex(n, len) {
    return n.toString(16).toUpperCase().padStart(len || 3, '0');
  }

  function disasm(op) {
    var x = (op >> 8) & 15, y = (op >> 4) & 15, n = op & 15, nn = op & 255, nnn = op & 0xFFF;
    var V = function (r) { return 'V' + r.toString(16).toUpperCase(); };
    switch (op >> 12) {
      case 0x0:
        if (op === 0x00E0) return 'CLS';
        if (op === 0x00EE) return 'RET';
        return 'SYS ' + hex(nnn);
      case 0x1: return 'JP ' + hex(nnn);
      case 0x2: return 'CALL ' + hex(nnn);
      case 0x3: return 'SE ' + V(x) + ', ' + hex(nn, 2);
      case 0x4: return 'SNE ' + V(x) + ', ' + hex(nn, 2);
      case 0x5: return 'SE ' + V(x) + ', ' + V(y);
      case 0x6: return 'LD ' + V(x) + ', ' + hex(nn, 2);
      case 0x7: return 'ADD ' + V(x) + ', ' + hex(nn, 2);
      case 0x8:
        var names = { 0: 'LD', 1: 'OR', 2: 'AND', 3: 'XOR', 4: 'ADD', 5: 'SUB', 6: 'SHR', 7: 'SUBN', 14: 'SHL' };
        return names[n] ? names[n] + ' ' + V(x) + ', ' + V(y) : '???';
      case 0x9: return 'SNE ' + V(x) + ', ' + V(y);
      case 0xA: return 'LD I, ' + hex(nnn);
      case 0xB: return 'JP V0, ' + hex(nnn);
      case 0xC: return 'RND ' + V(x) + ', ' + hex(nn, 2);
      case 0xD: return 'DRW ' + V(x) + ', ' + V(y) + ', ' + n;
      case 0xE:
        if (nn === 0x9E) return 'SKP ' + V(x);
        if (nn === 0xA1) return 'SKNP ' + V(x);
        return '???';
      case 0xF:
        switch (nn) {
          case 0x07: return 'LD ' + V(x) + ', DT';
          case 0x0A: return 'LD ' + V(x) + ', K';
          case 0x15: return 'LD DT, ' + V(x);
          case 0x18: return 'LD ST, ' + V(x);
          case 0x1E: return 'ADD I, ' + V(x);
          case 0x29: return 'LD F, ' + V(x);
          case 0x33: return 'LD B, ' + V(x);
          case 0x55: return 'LD [I], ' + V(x);
          case 0x65: return 'LD ' + V(x) + ', [I]';
        }
        return '???';
    }
    return '???';
  }

  function Chip28(quirks) {
    this.quirks = Object.assign({}, PRESETS.moderne, quirks || {});
    this.rom = null;
    this.keys = new Uint8Array(16);
    this.reset();
  }

  Chip28.W = W;
  Chip28.H = H;
  Chip28.PRESETS = PRESETS;
  Chip28.disasm = disasm;
  Chip28.hex = hex;

  Chip28.prototype.reset = function () {
    this.mem = new Uint8Array(4096);
    this.mem.set(FONT, 0);
    if (this.rom) this.mem.set(this.rom, START);
    this.V = new Uint8Array(16);
    this.I = 0;
    this.pc = START;
    this.sp = 0;
    this.stack = new Uint16Array(16);
    this.dt = 0;
    this.st = 0;
    this.display = new Uint8Array(W * H);
    this.halted = false;
    this.error = '';
    this.waitReg = -1;
    this.waitKey = -1;
    this.trace = new Int32Array(16);
    this.traceIdx = 0;
    this.keys.fill(0);
  };

  Chip28.prototype.loadRom = function (bytes) {
    if (bytes.length > 4096 - START) throw new Error('ROM trop grande (' + bytes.length + ' octets, maximum ' + (4096 - START) + ').');
    if (bytes.length === 0) throw new Error('Fichier vide.');
    this.rom = Uint8Array.from(bytes);
    this.reset();
  };

  Chip28.prototype.setQuirks = function (q) {
    this.quirks = Object.assign({}, this.quirks, q);
  };

  Chip28.prototype.halt = function (msg) {
    this.halted = true;
    this.error = msg;
  };

  Chip28.prototype.tickTimers = function () {
    if (this.dt > 0) this.dt--;
    if (this.st > 0) this.st--;
  };

  Chip28.prototype.run = function (cycles) {
    for (var i = 0; i < cycles && !this.halted; i++) this.step();
  };

  Chip28.prototype.step = function () {
    if (this.halted) return;
    var V = this.V, mem = this.mem, q = this.quirks;

    // FX0A : attendre l'appui puis le relâchement d'une touche
    if (this.waitReg >= 0) {
      if (this.waitKey < 0) {
        for (var k = 0; k < 16; k++) if (this.keys[k]) { this.waitKey = k; break; }
      } else if (!this.keys[this.waitKey]) {
        V[this.waitReg] = this.waitKey;
        this.waitReg = -1;
        this.waitKey = -1;
      }
      return;
    }

    var pc = this.pc;
    var op = (mem[pc] << 8) | mem[(pc + 1) & 0xFFF];
    this.pc = (pc + 2) & 0xFFF;
    this.trace[this.traceIdx] = (pc << 16) | op;
    this.traceIdx = (this.traceIdx + 1) & 15;

    var x = (op >> 8) & 15, y = (op >> 4) & 15, n = op & 15, nn = op & 255, nnn = op & 0xFFF;

    switch (op >> 12) {
      case 0x0:
        if (op === 0x00E0) { this.display.fill(0); }
        else if (op === 0x00EE) {
          if (this.sp === 0) return this.halt('Pile vide (RET sans CALL) en ' + hex(pc));
          this.pc = this.stack[--this.sp];
        } else return this.halt('Instruction inconnue ' + hex(op, 4) + ' en ' + hex(pc));
        break;
      case 0x1: this.pc = nnn; break;
      case 0x2:
        if (this.sp >= 16) return this.halt('Pile pleine (16 CALL imbriqués) en ' + hex(pc));
        this.stack[this.sp++] = this.pc;
        this.pc = nnn;
        break;
      case 0x3: if (V[x] === nn) this.pc = (this.pc + 2) & 0xFFF; break;
      case 0x4: if (V[x] !== nn) this.pc = (this.pc + 2) & 0xFFF; break;
      case 0x5:
        if (n !== 0) return this.halt('Instruction inconnue ' + hex(op, 4) + ' en ' + hex(pc));
        if (V[x] === V[y]) this.pc = (this.pc + 2) & 0xFFF;
        break;
      case 0x6: V[x] = nn; break;
      case 0x7: V[x] = (V[x] + nn) & 255; break;
      case 0x8: {
        var vx = V[x], vy = V[y], r, flag;
        switch (n) {
          case 0x0: V[x] = vy; break;
          case 0x1: V[x] = vx | vy; if (q.vfReset) V[0xF] = 0; break;
          case 0x2: V[x] = vx & vy; if (q.vfReset) V[0xF] = 0; break;
          case 0x3: V[x] = vx ^ vy; if (q.vfReset) V[0xF] = 0; break;
          case 0x4: r = vx + vy; V[x] = r & 255; V[0xF] = r > 255 ? 1 : 0; break;
          case 0x5: V[x] = (vx - vy) & 255; V[0xF] = vx >= vy ? 1 : 0; break;
          case 0x6: r = q.shiftUsesVY ? vy : vx; flag = r & 1; V[x] = r >> 1; V[0xF] = flag; break;
          case 0x7: V[x] = (vy - vx) & 255; V[0xF] = vy >= vx ? 1 : 0; break;
          case 0xE: r = q.shiftUsesVY ? vy : vx; flag = (r >> 7) & 1; V[x] = (r << 1) & 255; V[0xF] = flag; break;
          default: return this.halt('Instruction inconnue ' + hex(op, 4) + ' en ' + hex(pc));
        }
        break;
      }
      case 0x9:
        if (n !== 0) return this.halt('Instruction inconnue ' + hex(op, 4) + ' en ' + hex(pc));
        if (V[x] !== V[y]) this.pc = (this.pc + 2) & 0xFFF;
        break;
      case 0xA: this.I = nnn; break;
      case 0xB: this.pc = (nnn + V[0]) & 0xFFF; break;
      case 0xC: V[x] = (Math.random() * 256) & nn; break;
      case 0xD: {
        var px = V[x] % W, py = V[y] % H, hit = 0;
        for (var row = 0; row < n; row++) {
          var sy = py + row;
          if (sy >= H) { if (!q.wrap) break; sy %= H; }
          var bits = mem[(this.I + row) & 0xFFF];
          for (var col = 0; col < 8; col++) {
            if (!(bits & (0x80 >> col))) continue;
            var sx = px + col;
            if (sx >= W) { if (!q.wrap) break; sx %= W; }
            var idx = sy * W + sx;
            if (this.display[idx]) hit = 1;
            this.display[idx] ^= 1;
          }
        }
        V[0xF] = hit;
        break;
      }
      case 0xE:
        if (nn === 0x9E) { if (this.keys[V[x] & 15]) this.pc = (this.pc + 2) & 0xFFF; }
        else if (nn === 0xA1) { if (!this.keys[V[x] & 15]) this.pc = (this.pc + 2) & 0xFFF; }
        else return this.halt('Instruction inconnue ' + hex(op, 4) + ' en ' + hex(pc));
        break;
      case 0xF:
        switch (nn) {
          case 0x07: V[x] = this.dt; break;
          case 0x0A: this.waitReg = x; this.waitKey = -1; break;
          case 0x15: this.dt = V[x]; break;
          case 0x18: this.st = V[x]; break;
          case 0x1E: this.I = (this.I + V[x]) & 0xFFFF; break;
          case 0x29: this.I = (V[x] & 15) * 5; break;
          case 0x33:
            mem[this.I & 0xFFF] = Math.floor(V[x] / 100);
            mem[(this.I + 1) & 0xFFF] = Math.floor(V[x] / 10) % 10;
            mem[(this.I + 2) & 0xFFF] = V[x] % 10;
            break;
          case 0x55:
            for (var i = 0; i <= x; i++) mem[(this.I + i) & 0xFFF] = V[i];
            if (q.memIncrementI) this.I = (this.I + x + 1) & 0xFFFF;
            break;
          case 0x65:
            for (var j = 0; j <= x; j++) V[j] = mem[(this.I + j) & 0xFFF];
            if (q.memIncrementI) this.I = (this.I + x + 1) & 0xFFFF;
            break;
          default: return this.halt('Instruction inconnue ' + hex(op, 4) + ' en ' + hex(pc));
        }
        break;
    }
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Chip28;
  else root.Chip28 = Chip28;
})(typeof window !== 'undefined' ? window : this);


/* ROMs de démonstration intégrées (aucun serveur nécessaire). */
(function (root) {
  'use strict';
  var ROMS = [
    {
      id: 'demo-28',
      name: 'Démo « 28 »',
      desc: 'Affiche 28 avec la police intégrée.',
      bytes: [
        0x60, 0x0A, // V0 = 10
        0x61, 0x0C, // V1 = 12
        0x62, 0x02, // V2 = 2
        0xF2, 0x29, // I = glyphe de V2
        0xD0, 0x15, // dessiner en (V0,V1), 5 lignes
        0x70, 0x06, // V0 += 6
        0x62, 0x08, // V2 = 8
        0xF2, 0x29, // I = glyphe de V2
        0xD0, 0x15, // dessiner
        0x12, 0x12  // boucle infinie
      ]
    },
    {
      id: 'test-clavier',
      name: 'Test du clavier',
      desc: 'Appuie sur une touche du pavé : son chiffre s\u2019affiche.',
      bytes: [
        0x61, 0x1C, // V1 = 28 (x)
        0x62, 0x0D, // V2 = 13 (y)
        0xF0, 0x0A, // V0 = attendre une touche
        0x00, 0xE0, // effacer l'écran
        0xF0, 0x29, // I = glyphe de V0
        0xD1, 0x25, // dessiner en (V1,V2)
        0x12, 0x04  // retour à l'attente
      ]
    }
  ];
  root.CHIP28_ROMS = ROMS;
  if (typeof module !== 'undefined' && module.exports) module.exports = ROMS;
})(typeof window !== 'undefined' ? window : this);


/* Rendu de l'écran 64×32 et bip sonore. */
(function (root) {
  'use strict';

  var THEMES = {
    lcd:   { off: [185, 199, 154], on: [36, 46, 32] },
    ambre: { off: [38, 22, 6],     on: [255, 176, 40] },
    mono:  { off: [14, 14, 18],    on: [236, 236, 240] }
  };

  function Screen(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.img = this.ctx.createImageData(64, 32);
    this.level = new Float32Array(64 * 32);
    this.ghost = true;
    this.setTheme('lcd');
  }

  Screen.prototype.setTheme = function (name) {
    this.theme = THEMES[name] || THEMES.lcd;
    this.name = name;
  };

  Screen.prototype.render = function (display) {
    var d = this.img.data, off = this.theme.off, on = this.theme.on, lv = this.level;
    for (var i = 0; i < 2048; i++) {
      if (display[i]) lv[i] = 1;
      else lv[i] = this.ghost ? lv[i] * 0.72 : 0;
      var t = lv[i], o = i * 4;
      d[o]     = off[0] + (on[0] - off[0]) * t;
      d[o + 1] = off[1] + (on[1] - off[1]) * t;
      d[o + 2] = off[2] + (on[2] - off[2]) * t;
      d[o + 3] = 255;
    }
    this.ctx.putImageData(this.img, 0, 0);
  };

  function Beeper() {
    this.ctx = null;
    this.gain = null;
    this.enabled = true;
  }

  // À appeler après un geste de l'utilisateur (clic, touche) : les navigateurs bloquent le son avant.
  Beeper.prototype.unlock = function () {
    if (!this.ctx) {
      var AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.gain = this.ctx.createGain();
      this.gain.gain.value = 0;
      this.gain.connect(this.ctx.destination);
      var osc = this.ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.value = 440;
      osc.connect(this.gain);
      osc.start();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  };

  Beeper.prototype.set = function (on) {
    if (!this.ctx) return;
    this.gain.gain.setTargetAtTime(on && this.enabled ? 0.07 : 0, this.ctx.currentTime, 0.005);
  };

  root.Chip28Screen = Screen;
  root.Chip28Beeper = Beeper;
})(typeof window !== 'undefined' ? window : this);


// Tests rapides du cœur : node test.js
const Chip28 = require('./js/cpu.js');
const ROMS = require('./js/roms.js');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('ECHEC:', m); } else console.log('ok   :', m); };

function ascii(c) {
  let s = '';
  for (let y = 0; y < 32; y++) { for (let x = 0; x < 64; x++) s += c.display[y*64+x] ? '#' : '.'; s += '\n'; }
  return s;
}

// 1. Démo « 28 »
let c = new Chip28(); c.loadRom(ROMS[0].bytes); c.run(50);
const lit = c.display.reduce((a, b) => a + b, 0);
ok(!c.halted, 'la démo tourne sans erreur');
ok(lit > 20, 'la démo dessine des pixels (' + lit + ')');
console.log(ascii(c).split('\n').slice(10, 19).join('\n'));

// 2. Test clavier
c = new Chip28(); c.loadRom(ROMS[1].bytes); c.run(20);
ok(c.waitReg === 0, 'attend une touche');
c.keys[7] = 1; c.run(5); c.keys[7] = 0; c.run(30);
ok(c.display.reduce((a, b) => a + b, 0) > 5, 'affiche le chiffre 7 après appui+relâchement');

// 3. Arithmétique
function prog(bytes, quirks) { const k = new Chip28(quirks); k.loadRom(bytes); k.run(bytes.length / 2); return k; }
let k = prog([0x60,0xFF, 0x61,0x02, 0x80,0x14]);               // V0=FF, V1=2, V0+=V1
ok(k.V[0] === 0x01 && k.V[0xF] === 1, 'ADD avec retenue');
k = prog([0x60,0x05, 0x61,0x07, 0x80,0x15]);                   // 5-7
ok(k.V[0] === 0xFE && k.V[0xF] === 0, 'SUB avec emprunt');
k = prog([0x60,0x03, 0x61,0x06, 0x80,0x16]);                   // SHR moderne : utilise VX
ok(k.V[0] === 0x01 && k.V[0xF] === 1, 'SHR moderne (VX)');
k = prog([0x60,0x03, 0x61,0x06, 0x80,0x16], { shiftUsesVY: true });
ok(k.V[0] === 0x03 && k.V[0xF] === 0, 'SHR COSMAC (VY)');
k = prog([0x60,0xFE, 0x6F,0x00, 0x80,0x04]);
ok(true, 'pas de plantage sur VF comme destination');

// 4. BCD, mémoire, pile
k = prog([0x60,0xEA, 0xA3,0x00, 0xF0,0x33]);                   // 234
ok(k.mem[0x300] === 2 && k.mem[0x301] === 3 && k.mem[0x302] === 4, 'BCD de 234');
k = prog([0x60,0x11, 0x61,0x22, 0xA3,0x00, 0xF1,0x55]);
ok(k.mem[0x300] === 0x11 && k.mem[0x301] === 0x22 && k.I === 0x300, 'FX55 sans incrément de I');
k = prog([0x60,0x11, 0x61,0x22, 0xA3,0x00, 0xF1,0x55], { memIncrementI: true });
ok(k.I === 0x302, 'FX55 avec incrément de I (COSMAC)');
k = new Chip28(); k.loadRom([0x22,0x04, 0x12,0x02, 0x00,0xEE]); k.run(1);
ok(k.pc === 0x204 && k.sp === 1, 'CALL empile');
k.run(1); ok(k.pc === 0x202 && k.sp === 0, 'RET dépile');

// 5. Collision et clipping
k = new Chip28(); k.loadRom([0xA0,0x00, 0xD0,0x05, 0xD0,0x05]); k.run(3);
ok(k.V[0xF] === 1 && k.display.reduce((a,b)=>a+b,0) === 0, 'dessiner deux fois efface et lève VF');
k = new Chip28(); k.loadRom([0x60,0x3E, 0xA0,0x00, 0xD0,0x05]); k.run(3);
let wrapped = 0; for (let y = 0; y < 32; y++) for (let x = 0; x < 2; x++) wrapped += k.display[y*64+x];
ok(wrapped === 0, 'sprite coupé au bord (pas de rebouclage)');

// 6. Erreurs gérées
k = new Chip28(); k.loadRom([0x00,0xEE]); k.run(1);
ok(k.halted && /Pile vide/.test(k.error), 'RET sans CALL signalé');
k = new Chip28(); k.loadRom([0x5A,0xB1]); k.run(1);
ok(k.halted, 'opcode inconnu signalé');
let threw = false; try { new Chip28().loadRom(new Uint8Array(4000)); } catch (e) { threw = true; }
ok(threw, 'ROM trop grande refusée');

console.log(fails ? '\n' + fails + ' échec(s)' : '\nTout est bon');
process.exit(fails ? 1 : 0);
